from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path
from time import perf_counter
from threading import RLock, local
from typing import Any, Callable

import networkx as nx

from .context import JobContext
from .errors import InvalidGraphError, InvalidJobError, JobFailedError
from .models import (
    CANCELLED,
    DONE,
    FAILED,
    Job,
    NODE_COMPLETE_STATUSES,
    QUEUED,
    RUNNING,
    SKIPPED,
    SUCCESSFUL_JOB_TERMINAL_STATUSES,
    now,
)
from .node import (
    JobNode,
    sequential_runner_value,
    validate_non_negative_int,
    validate_positive_int,
)
from .router import NodeRouter, import_modules_from_dir, routers_from_module
from .runners.direct import DirectRunner
from .runners.process import ProcessPoolRunner
from .runners.threaded import ThreadedRunner
from .storage import FileStorage


def normalize_workflow_runner(runner: str) -> str:
    aliases = {
        "thread": "threaded",
        "processes": "process",
        "process_pool": "process",
        "processpool": "process",
    }
    runner = aliases.get(runner, runner)

    if runner not in {"direct", "threaded", "process"}:
        raise ValueError(f"Unknown runner: {runner}")

    return runner


class MicroWorkflow:
    def __init__(
        self,
        project_dir: str | Path = "project",
        runner: str = "threaded",
        process_graph_path: str | Path | None = None,
    ):
        runner = normalize_workflow_runner(runner)

        self.storage = FileStorage(project_dir)
        self.runner = runner
        self.process_graph_path = (
            Path(process_graph_path).resolve()
            if process_graph_path is not None
            else None
        )

        self.graph_obj = nx.DiGraph()
        self.nodes: dict[str, JobNode] = {}
        self.lock = RLock()
        self._included_router_ids: set[int] = set()

        # CLI safety controls. Normal library use keeps immediate autostarts.
        self.allowed_run_nodes: set[str] | None = None
        self.autostart_mode = "immediate"

        # Job-spawn context. A task may create more jobs with autostart=True,
        # but those spawned jobs must be treated like newly-created entities in
        # a game loop: enqueue them and let the component scheduler run them.
        # Running them recursively from inside the parent job can deadlock a
        # cyclic component when every worker is waiting for a child worker.
        self._job_context = local()

    def graph(self, edges: list[tuple[str, str]]):
        with self.lock:
            for start, end in edges:
                self.ensure_node(start)
                self.ensure_node(end)
                self.graph_obj.add_edge(start, end)

            # Cycles are allowed. A strongly connected component is treated as
            # one communicating class for readiness and completion. This lets
            # autostart loops such as A -> A or A -> B -> A keep generating
            # jobs until the whole component becomes quiescent.
            self.storage.write_graph(edges)

    def include_router(self, router):
        """Mount a NodeRouter or a module that exports router/routers.

        This is similar in spirit to FastAPI's app.include_router(...).
        """
        if isinstance(router, NodeRouter):
            router_id = id(router)

            if router_id in self._included_router_ids:
                return router

            router.mount_to(self)
            self._included_router_ids.add(router_id)
            return router

        found = routers_from_module(router)

        if not found:
            raise ValueError("include_router expected a NodeRouter or a module with router/routers")

        for item in found:
            self.include_router(item)

        return router

    def include_routers(self, *routers):
        for router in routers:
            self.include_router(router)

    def include_router_dir(
        self,
        directory: str | Path,
        package: str | None = None,
        recursive: bool = False,
    ):
        """Import every node file in a folder and mount its router.

        This supports the recommended layout:

            src/node_behavior/load_recipes.py
            src/node_behavior/make_card.py
            src/node_behavior/index_cards.py
        """
        modules = import_modules_from_dir(
            directory=directory,
            package=package,
            recursive=recursive,
        )

        for module in modules:
            for router in routers_from_module(module):
                self.include_router(router)

        return modules

    # Friendly aliases if you prefer thinking in nodes instead of routers.
    include_node = include_router
    include_nodes = include_routers
    include_node_dir = include_router_dir

    def ensure_node(
        self,
        name: str,
        max_threads: int = 5,
        runner: str | None = None,
        sequential: bool = False,
    ) -> JobNode:
        name = self.storage.validate_node_name(name)
        max_threads = validate_positive_int("max_threads", max_threads)
        runner_override = sequential_runner_value(runner=runner, sequential=sequential)

        if runner_override == "direct":
            max_threads = 1

        with self.lock:
            if name not in self.nodes:
                self.nodes[name] = JobNode(
                    name,
                    max_threads=max_threads,
                    runner=runner_override,
                )
                self.graph_obj.add_node(name)
                self.storage.init_node_folders(name)

                if self.storage.get_node_status(name) is None:
                    self.storage.set_node_status(name, QUEUED)
            else:
                node = self.nodes[name]
                if runner_override is not None:
                    node.set_runner(runner=runner_override)

            return self.nodes[name]

    def task(
        self,
        node_name: str,
        max_threads: int = 5,
        retries: int = 0,
        repeats: int = 1,
        runner: str | None = None,
        sequential: bool = False,
    ):
        max_threads_checked = validate_positive_int("max_threads", max_threads)
        retries_checked = validate_non_negative_int("retries", retries)
        repeats_checked = validate_positive_int("repeats", repeats)
        runner_override = sequential_runner_value(runner=runner, sequential=sequential)

        if runner_override == "direct":
            max_threads_checked = 1

        def decorator(fn: Callable):
            node = self.ensure_node(
                node_name,
                max_threads=max_threads_checked,
                runner=runner_override,
            )
            node.max_threads = max_threads_checked
            if runner_override is not None:
                node.set_runner(runner=runner_override)
            node.mount_main(fn, retries=retries_checked, repeats=repeats_checked)

            assert node.main_task is not None

            self.storage.write_node_schema(
                node_name=node_name,
                allowed_params=node.main_task.allowed_params,
                required_params=node.main_task.required_params,
                retries=node.main_task.retries,
                repeats=node.main_task.repeats,
                fallbacks=node.fallback_order,
                runner_override=node.runner_override,
                max_threads=node.max_threads,
            )

            return fn

        return decorator

    def fallback(
        self,
        node_name: str,
        name: str | None = None,
        retries: int = 0,
        repeats: int = 1,
    ):
        retries_checked = validate_non_negative_int("retries", retries)
        repeats_checked = validate_positive_int("repeats", repeats)

        def decorator(fn: Callable):
            node = self.ensure_node(node_name)
            node.mount_fallback(
                handler=fn,
                name=name,
                retries=retries_checked,
                repeats=repeats_checked,
            )

            if node.main_task is not None:
                self.storage.write_node_schema(
                    node_name=node_name,
                    allowed_params=node.main_task.allowed_params,
                    required_params=node.main_task.required_params,
                    retries=node.main_task.retries,
                    repeats=node.main_task.repeats,
                    fallbacks=node.fallback_order,
                    runner_override=node.runner_override,
                    max_threads=node.max_threads,
                )

            return fn

        return decorator

    def validate_edge(self, from_node: str, to_node: str):
        if not self.graph_obj.has_edge(from_node, to_node):
            raise InvalidGraphError(f"{from_node} cannot create jobs on {to_node}")

    def start(
        self,
        node_name: str,
        job_id: int | None = None,
        autostart: bool = False,
        **params,
    ):
        return self.add_job(
            from_node=None,
            to_node=node_name,
            job_id=job_id,
            autostart=autostart,
            **params,
        )

    def create_jobs(
        self,
        node_name: str,
        *,
        number: int = 1,
        params: dict[str, Any] | None = None,
        start_job_id: int = 1,
    ) -> list[Job]:
        """Create deterministic default jobs for a node.

        This is the workflow-level companion to ``NodeRouter.create_job``.
        Existing default jobs with the same ids are refreshed in-place instead
        of duplicated, so importing routers during CLI commands is idempotent.
        """
        number = validate_positive_int("number", number)
        start_job_id = self.storage.validate_job_id(start_job_id)

        if params is None:
            params = {}

        if not isinstance(params, dict):
            raise ValueError("params must be a dict")

        # Reject unserializable params before writing anything.
        self.storage.json_text(Path("create_job_params.json"), params)

        node = self.ensure_node(node_name)
        created: list[Job] = []
        changed_any_job = False

        with self.storage.interprocess_lock(f"node-{node_name}-jobs"):
            with node.lock:
                node.validate_params(params)

                if self.storage.default_job_spec_current(
                    node_name,
                    start_job_id=start_job_id,
                    number=number,
                    params=params,
                ):
                    return [
                        Job(
                            job_id=start_job_id + offset,
                            node_name=node_name,
                            params=dict(params),
                            parent=None,
                        )
                        for offset in range(number)
                    ]

                for offset in range(number):
                    job_id = start_job_id + offset
                    existed = self.storage.job_exists(node_name, job_id)
                    previous_params = None
                    previous_parent = None
                    previous_status = None

                    if existed:
                        previous_params = self.storage.read_json(
                            self.storage.input_file(node_name, job_id),
                            default={},
                        )
                        previous_job_data = self.storage.read_json(
                            self.storage.job_file(node_name, job_id),
                            default={},
                        )
                        previous_parent = previous_job_data.get("parent")
                        previous_status = self.storage.get_job_status(node_name, job_id)

                    job = Job(
                        job_id=job_id,
                        node_name=node_name,
                        params=dict(params),
                        parent=None,
                    )
                    self.storage.ensure_job(job)
                    created.append(job)

                    if (
                        not existed
                        or previous_params != job.params
                        or previous_parent is not None
                        or previous_status is None
                    ):
                        changed_any_job = True

                self.storage.write_default_job_spec(
                    node_name,
                    start_job_id=start_job_id,
                    number=number,
                    params=params,
                )

                # Router-declared jobs are mounted every time the CLI loads the
                # workflow. Re-mounting an unchanged default job must not erase a
                # previously completed node status, otherwise `mwf run A` followed by
                # `mwf run B` would make B think A is unfinished. Only mark the node
                # queued when a default job was actually created, refreshed, or fixed.
                if changed_any_job:
                    self.storage.set_node_status(node_name, QUEUED)

        return created

    def add_job(
        self,
        from_node: str | None,
        to_node: str,
        job_id: int | None = None,
        autostart: bool = False,
        _parent_job_id: int | None = None,
        **params,
    ):
        if job_id is not None:
            self.storage.validate_job_id(job_id)

        if _parent_job_id is not None:
            self.storage.validate_job_id(_parent_job_id)

        if from_node is not None:
            self.validate_edge(from_node, to_node)

        if autostart and self.allowed_run_nodes is not None and to_node not in self.allowed_run_nodes:
            parent = f"{from_node}/{_parent_job_id}" if _parent_job_id is not None else str(from_node)
            raise InvalidGraphError(
                f"Autostart from {parent} to {to_node} was blocked because "
                f"{to_node} is outside the approved run set. "
                "Use mwf run/runfrom and approve detected autostarts, or include "
                "the target node in the run set. Dynamic autostarts may not be "
                "found by the static scanner."
            )

        node = self.ensure_node(to_node)

        with self.storage.interprocess_lock(f"node-{to_node}-jobs"):
            with node.lock:
                node.validate_params(params)

                if job_id is None:
                    job_id = self.storage.next_job_id(to_node)

                parent = None
                if from_node is not None:
                    parent = {
                        "from_node": from_node,
                        "from_job_id": _parent_job_id,
                    }

                job = Job(
                    job_id=job_id,
                    node_name=to_node,
                    params=params,
                    parent=parent,
                )

                self.storage.create_job(job)
                self.storage.set_node_status(to_node, QUEUED)

        if autostart and self.autostart_mode == "immediate":
            # Outside a running task, preserve the old convenience behavior:
            # start the requested job now. Inside a running task, preserve
            # immediate DAG autostart, but never recursively execute a job in
            # the same strongly-connected component. Same-component spawns are
            # queued as game-engine entities and picked up by the component pump.
            current_node = getattr(self._job_context, "node_name", None)
            same_component_spawn = (
                current_node is not None
                and to_node in self.component_for(current_node)
            )
            if not same_component_spawn:
                return self.run_job(
                    node_name=to_node,
                    job_id=job_id,
                    ignore_readiness=True,
                )

        return job

    def node_complete(self, node_name: str) -> bool:
        return self.storage.get_node_status(node_name) in NODE_COMPLETE_STATUSES

    def strongly_connected_components(self) -> list[set[str]]:
        return [set(component) for component in nx.strongly_connected_components(self.graph_obj)]

    def component_for(self, node_name: str) -> set[str]:
        for component in self.strongly_connected_components():
            if node_name in component:
                return component
        return {node_name}

    def component_is_cyclic(self, component: set[str]) -> bool:
        return len(component) > 1 or any(
            self.graph_obj.has_edge(node_name, node_name)
            for node_name in component
        )

    def component_predecessors(self, component: set[str]) -> set[str]:
        predecessors: set[str] = set()

        for node_name in component:
            predecessors.update(self.graph_obj.predecessors(node_name))

        return predecessors - component

    def component_ready(self, component: set[str]) -> bool:
        return all(self.node_complete(node) for node in self.component_predecessors(component))

    def component_has_any_jobs(self, component: set[str]) -> bool:
        return any(self.storage.list_jobs(node_name) for node_name in component)

    def refresh_component_status(self, component: set[str], allow_complete: bool = False):
        """Refresh a strongly connected component as one communicating class.

        This uses the per-node job index instead of list_jobs(), so refreshing a
        cyclic autostart component is O(number of nodes) rather than repeatedly
        scanning thousands of job folders after every small routing update.
        """
        component = set(component)
        counts_by_node = {
            node_name: self.storage.job_status_counts(node_name)
            for node_name in component
        }
        totals_by_node = {
            node_name: sum(counts.values())
            for node_name, counts in counts_by_node.items()
        }
        total_jobs = sum(totals_by_node.values())

        if total_jobs == 0:
            for node_name in component:
                current_status = self.storage.get_node_status(node_name)
                if current_status in {DONE, FAILED, CANCELLED, SKIPPED}:
                    continue
                self.storage.set_node_status(node_name, QUEUED)
            return

        if any(counts.get(FAILED, 0) for counts in counts_by_node.values()):
            for node_name in component:
                self.storage.set_node_status(node_name, FAILED)
            return

        has_running_or_queued = any(
            counts.get(RUNNING, 0) or counts.get(QUEUED, 0)
            for counts in counts_by_node.values()
        )
        if has_running_or_queued:
            for node_name, counts in counts_by_node.items():
                if counts.get(RUNNING, 0):
                    self.storage.set_node_status(node_name, RUNNING)
                else:
                    self.storage.set_node_status(node_name, QUEUED)
            return

        successful_terminal = {DONE, SKIPPED}
        all_terminal_success = all(
            totals_by_node[node_name] > 0
            and sum(counts_by_node[node_name].get(status, 0) for status in successful_terminal) == totals_by_node[node_name]
            for node_name in component
        )

        if all_terminal_success:
            if allow_complete and self.component_ready(component):
                for node_name in component:
                    self.storage.set_node_status(node_name, DONE)
            else:
                for node_name in component:
                    self.storage.set_node_status(node_name, QUEUED)
            return

        for node_name in component:
            self.storage.set_node_status(node_name, QUEUED)

    def node_ready(self, node_name: str) -> bool:
        return self.component_ready(self.component_for(node_name))

    def refresh_node_status(self, node_name: str, allow_complete: bool = False):
        """Refresh a node or cyclic component without unsafe early completion.

        Uses the per-node job index rather than list_jobs(), avoiding a full
        status-file scan every time a node or component is considered for
        readiness/finalization.
        """
        component = self.component_for(node_name)

        if self.component_is_cyclic(component):
            self.refresh_component_status(component, allow_complete=allow_complete)
            return

        counts = self.storage.job_status_counts(node_name)
        total = sum(counts.values())

        if total == 0:
            current_status = self.storage.get_node_status(node_name)
            if current_status in {DONE, FAILED, CANCELLED, SKIPPED}:
                return
            self.storage.set_node_status(node_name, QUEUED)
            return

        if counts.get(FAILED, 0):
            self.storage.set_node_status(node_name, FAILED)
            return

        if counts.get(RUNNING, 0):
            self.storage.set_node_status(node_name, RUNNING)
            return

        if counts.get(QUEUED, 0):
            self.storage.set_node_status(node_name, QUEUED)
            return

        successful = counts.get(DONE, 0) + counts.get(SKIPPED, 0)
        if successful == total:
            if allow_complete and self.node_ready(node_name):
                self.storage.set_node_status(node_name, DONE)
            else:
                self.storage.set_node_status(node_name, QUEUED)
            return

        self.storage.set_node_status(node_name, QUEUED)

    def finalize_ready_nodes(self):
        for node_name in self.graph_obj.nodes:
            if self.node_ready(node_name):
                self.refresh_node_status(node_name, allow_complete=True)

    def ready_nodes(self) -> list[str]:
        self.finalize_ready_nodes()
        ready = []

        for node_name in self.graph_obj.nodes:
            if self.storage.has_queued_jobs(node_name) and self.node_ready(node_name):
                ready.append(node_name)

        return ready

    def make_runner(self, node: JobNode):
        effective_runner = node.runner_override or self.runner

        if effective_runner == "direct":
            return DirectRunner()

        if effective_runner == "threaded":
            return ThreadedRunner(max_threads=node.max_threads)

        if effective_runner == "process":
            return ProcessPoolRunner(
                max_processes=node.max_threads,
                project_dir=self.storage.project_dir,
                graph_path=self.process_graph_path,
                allowed_run_nodes=self.allowed_run_nodes,
                autostart_mode=self.autostart_mode,
            )

        raise ValueError(f"Unknown runner: {effective_runner}")

    def run(self):
        if self.runner in {"threaded", "process"}:
            return self.run_concurrently()

        ran = []

        while True:
            ready = self.ready_nodes()

            if not ready:
                break

            for node_name in ready:
                self.run_node(node_name)
                ran.append(node_name)

        return ran

    def component_key(self, component: set[str]) -> tuple[str, ...]:
        node_order = {node_name: index for index, node_name in enumerate(self.graph_obj.nodes)}
        return tuple(sorted(component, key=lambda item: node_order.get(item, 10**9)))

    def execution_components(self, nodes: list[str] | None = None) -> list[tuple[str, ...]]:
        """Return unique SCC execution units in component-topological order.

        A strongly connected component is one scheduler-owned unit. This is the
        game-engine/entity-spawn rule for cyclic autostart graphs: jobs may
        create more jobs in any node of the component, and the component is
        pumped until it is quiescent.
        """
        selected = set(self.graph_obj.nodes if nodes is None else nodes)
        if not selected:
            return []

        components = [set(component) for component in nx.strongly_connected_components(self.graph_obj)]
        component_by_node = {
            node_name: index
            for index, component in enumerate(components)
            for node_name in component
        }

        component_graph = nx.DiGraph()
        component_graph.add_nodes_from(range(len(components)))

        for start, end in self.graph_obj.edges:
            start_component = component_by_node[start]
            end_component = component_by_node[end]
            if start_component != end_component:
                component_graph.add_edge(start_component, end_component)

        units: list[tuple[str, ...]] = []
        seen: set[int] = set()

        for component_index in nx.topological_sort(component_graph):
            component = components[component_index]
            if not component.intersection(selected):
                continue
            if component_index in seen:
                continue
            seen.add(component_index)
            units.append(self.component_key(component))

        return units

    def component_has_queued_jobs(self, component: set[str]) -> bool:
        return any(self.storage.has_queued_jobs(node_name) for node_name in component)

    def run_component(
        self,
        component: set[str] | tuple[str, ...] | list[str],
        ignore_readiness: bool = False,
    ) -> list[str]:
        """Pump one SCC/component until it has no queued jobs left.

        This is deliberately not recursive autostart. Child jobs spawned by a
        running job are queued as new entities, then picked up by this component
        pump after the current worker returns. The component is marked complete
        only when all jobs across all nodes in the SCC are terminal.
        """
        component_set = set(component)
        if not component_set:
            return []

        if not ignore_readiness and not self.component_ready(component_set):
            raise InvalidGraphError(
                f"Component {sorted(component_set)} is not ready yet"
            )

        ran: list[str] = []
        component_nodes = list(self.component_key(component_set))

        while True:
            queued_nodes = [
                node_name
                for node_name in component_nodes
                if self.storage.has_queued_jobs(node_name)
            ]

            if not queued_nodes:
                self.refresh_component_status(component_set, allow_complete=True)
                return ran

            for node_name in queued_nodes:
                self.storage.set_node_status(node_name, RUNNING)

            if self.runner == "direct":
                for node_name in queued_nodes:
                    self.run_queued_node_jobs(node_name, ignore_readiness=True)
                    ran.append(node_name)
                continue

            max_workers = max(1, len(queued_nodes))
            futures = {}
            with ThreadPoolExecutor(
                max_workers=max_workers,
                thread_name_prefix="mwf-component-node",
            ) as executor:
                for node_name in queued_nodes:
                    futures[executor.submit(
                        self.run_queued_node_jobs,
                        node_name,
                        True,
                    )] = node_name

                done, not_done = wait(futures, return_when=FIRST_COMPLETED)

                first_error = None
                while done:
                    for future in done:
                        node_name = futures.pop(future)
                        try:
                            future.result()
                        except Exception as error:
                            first_error = error
                            break
                        ran.append(node_name)

                    if first_error is not None:
                        for pending in not_done:
                            pending.cancel()
                        wait(not_done)
                        raise first_error

                    if not futures:
                        break

                    done, not_done = wait(futures, return_when=FIRST_COMPLETED)

    def run_concurrently(
        self,
        nodes: list[str] | None = None,
        ready_check: Callable[[str], bool] | None = None,
    ) -> list[str]:
        """Run ready execution units concurrently.

        A cyclic SCC is scheduled as one execution unit, not as several
        independent node schedulers. This prevents autostart cycles such as
        A -> B -> A from starting competing schedulers that fight over the same
        queue/status files or recursively wait on child jobs.
        """
        units = self.execution_components(nodes)
        if not units:
            return []

        def default_ready_check(node_name: str) -> bool:
            return self.node_ready(node_name)

        check = ready_check or default_ready_check

        def unit_ready(unit: tuple[str, ...]) -> bool:
            return any(self.storage.has_queued_jobs(node_name) for node_name in unit) and all(
                check(node_name) for node_name in unit
            )

        max_workers = max(1, len(units))
        ran: list[str] = []
        in_flight: set[tuple[str, ...]] = set()
        futures = {}

        with ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix="mwf-unit",
        ) as executor:
            while True:
                self.finalize_ready_nodes()

                ready = [
                    unit
                    for unit in units
                    if unit not in in_flight
                    and unit_ready(unit)
                ]

                for unit in ready:
                    future = executor.submit(
                        self.run_component,
                        set(unit),
                        True,
                    )
                    futures[future] = unit
                    in_flight.add(unit)

                if not futures:
                    break

                done, _ = wait(futures, return_when=FIRST_COMPLETED)

                for future in done:
                    unit = futures.pop(future)
                    in_flight.remove(unit)

                    try:
                        ran.extend(future.result())
                    except Exception:
                        for pending in futures:
                            pending.cancel()
                        wait(futures)
                        raise

        self.finalize_ready_nodes()
        return ran

    def run_node(self, node_name: str, ignore_readiness: bool = False):
        if not ignore_readiness and not self.node_ready(node_name):
            raise InvalidGraphError(f"Node {node_name} is not ready yet")

        # Make the node-level status flip immediately. Queued jobs are then
        # streamed to the runner by ID, so execution can start before every job
        # folder has been scanned and before every input.json has been loaded.
        self.storage.set_node_status(node_name, RUNNING)

        return self.run_queued_node_jobs(
            node_name=node_name,
            ignore_readiness=True,
        )

    def run_queued_node_jobs(
        self,
        node_name: str,
        ignore_readiness: bool = False,
    ):
        """Run all currently queued jobs for one node using a lazy job source."""
        if not ignore_readiness and not self.node_ready(node_name):
            raise InvalidGraphError(f"Node {node_name} is not ready yet")

        node = self.nodes[node_name]

        if not self.storage.has_queued_jobs(node_name):
            self.refresh_node_status(node_name, allow_complete=True)
            return []

        self.storage.set_node_status(node_name, RUNNING)
        runner = self.make_runner(node)

        try:
            result = runner.run_job_source(
                node_name=node_name,
                job_source=self.storage.iter_queued_job_ids(node_name),
                run_one=lambda job_id: self.run_job(
                    node_name=node_name,
                    job_id=job_id,
                    ignore_readiness=True,
                ),
            )

        except Exception:
            self.storage.set_node_status(node_name, FAILED)
            raise

        self.refresh_node_status(node_name, allow_complete=True)

        return result

    def run_node_jobs(
        self,
        node_name: str,
        jobs: list[Job],
        ignore_readiness: bool = False,
    ):
        """Run a specific list of jobs from one node.

        This is the shared implementation for normal node runs and the CLI's
        job-selection mode. The supplied jobs are the only jobs executed; other
        queued jobs on the same node are left untouched.
        """
        if not ignore_readiness and not self.node_ready(node_name):
            raise InvalidGraphError(f"Node {node_name} is not ready yet")

        node = self.nodes[node_name]

        if not jobs:
            self.refresh_node_status(node_name, allow_complete=True)
            return []

        self.storage.set_node_status(node_name, RUNNING)

        runner = self.make_runner(node)

        try:
            result = runner.run_jobs(
                node_name=node_name,
                jobs=jobs,
                run_one=lambda job: self.run_job(
                    node_name=job.node_name,
                    job_id=job.job_id,
                    ignore_readiness=True,
                ),
            )

        except Exception:
            self.storage.set_node_status(node_name, FAILED)
            raise

        self.refresh_node_status(node_name, allow_complete=True)

        return result

    def run_jobs(
        self,
        node_name: str,
        job_ids: list[int],
        ignore_readiness: bool = False,
    ):
        """Run selected job IDs from one node.

        Unlike run_node(...), this does not gather every queued job. It loads the
        exact job IDs requested by the caller and runs only those jobs.
        """
        if not job_ids:
            return []

        jobs = [self.storage.load_job(node_name, job_id) for job_id in job_ids]
        return self.run_node_jobs(
            node_name=node_name,
            jobs=jobs,
            ignore_readiness=ignore_readiness,
        )

    def run_job(
        self,
        node_name: str,
        job_id: int,
        ignore_readiness: bool = False,
    ):
        if not ignore_readiness and not self.node_ready(node_name):
            raise InvalidGraphError(f"Node {node_name} is not ready yet")

        job = self.storage.load_job(node_name, job_id)
        node = self.nodes[node_name]

        if node.main_task is None:
            raise InvalidJobError(f"Node {node_name} has no mounted task")

        started_at = now()
        started_perf = perf_counter()
        self.storage.set_job_status(node_name, job_id, RUNNING, started_at=started_at)

        try:
            previous_node_name = getattr(self._job_context, "node_name", None)
            previous_job_id = getattr(self._job_context, "job_id", None)
            self._job_context.node_name = node_name
            self._job_context.job_id = job_id
            try:
                result = self.execute_with_fallbacks(job)
            finally:
                self._job_context.node_name = previous_node_name
                self._job_context.job_id = previous_job_id

            stored_files = self.storage.store_returned_files(node_name, job_id, result)

            self.storage.write_output(
                node_name,
                job_id,
                {
                    "status": DONE,
                    "stored_files": stored_files,
                    "result_type": type(result).__name__,
                    "result_repr": repr(result),
                },
            )

            self.storage.set_job_status(
                node_name,
                job_id,
                DONE,
                started_at=started_at,
                finished_at=now(),
                duration_seconds=round(perf_counter() - started_perf, 6),
            )

            if self.storage.get_node_status(node_name) != RUNNING:
                self.refresh_node_status(node_name, allow_complete=False)

            return result

        except Exception as error:
            self.storage.write_debug(
                node_name,
                f"job {job_id} failed: {error}",
            )

            self.storage.write_output(
                node_name,
                job_id,
                {
                    "status": FAILED,
                    "error": repr(error),
                },
            )

            self.storage.set_job_status(
                node_name,
                job_id,
                FAILED,
                started_at=started_at,
                finished_at=now(),
                duration_seconds=round(perf_counter() - started_perf, 6),
            )

            if self.storage.get_node_status(node_name) != RUNNING:
                self.refresh_node_status(node_name, allow_complete=False)

            raise JobFailedError(f"Job {node_name}/{job_id} failed") from error

    def execute_with_fallbacks(self, job: Job):
        node = self.nodes[job.node_name]
        assert node.main_task is not None

        try:
            return self.execute_mounted_task(job, node.main_task)

        except Exception as main_error:
            self.storage.write_debug(
                job.node_name,
                f"job {job.job_id} main task failed: {main_error}",
            )

            for fallback_name in node.fallback_order:
                fallback = node.fallbacks[fallback_name]

                self.storage.write_debug(
                    job.node_name,
                    f"job {job.job_id} trying fallback {fallback_name}",
                )

                try:
                    return self.execute_mounted_task(
                        job,
                        fallback,
                        previous_error=main_error,
                    )

                except Exception as fallback_error:
                    self.storage.write_debug(
                        job.node_name,
                        f"job {job.job_id} fallback {fallback_name} failed: {fallback_error}",
                    )

            raise main_error

    def execute_mounted_task(
        self,
        job: Job,
        mounted,
        previous_error: Exception | None = None,
    ):
        attempts = mounted.retries + 1
        all_results = []

        for attempt in range(1, attempts + 1):
            try:
                repeat_results = []

                for repeat_index in range(1, mounted.repeats + 1):
                    ctx = JobContext(
                        system=self,
                        current_node=job.node_name,
                        current_job=job,
                        current_task=mounted.name,
                        attempt=attempt,
                        repeat_index=repeat_index,
                        error=previous_error,
                    )

                    params = {
                        key: value
                        for key, value in job.params.items()
                        if key in mounted.allowed_params
                    }

                    if "error" in mounted.allowed_params:
                        params["error"] = previous_error

                    missing = mounted.required_params - set(params)
                    if missing:
                        raise InvalidJobError(
                            f"Missing params for {job.node_name}.{mounted.name}: {missing}"
                        )

                    result = mounted.handler(ctx, **params)
                    repeat_results.append(result)

                all_results.extend(repeat_results)
                return all_results[0] if len(all_results) == 1 else all_results

            except Exception as error:
                if attempt < attempts:
                    self.storage.write_debug(
                        job.node_name,
                        f"job {job.job_id} retrying {mounted.name} "
                        f"attempt {attempt + 1}/{attempts}: {error}",
                    )
                    continue

                raise

    def run_one(self, node_name: str, **params):
        job = self.start(
            node_name,
            autostart=False,
            **params,
        )

        result = self.run_job(
            node_name=node_name,
            job_id=job.job_id,
            ignore_readiness=True,
        )
        self.refresh_node_status(node_name, allow_complete=True)
        return result

    def run_node_once(self, node_name: str):
        return self.run_node(
            node_name,
            ignore_readiness=True,
        )

    def list_jobs(self, node_name: str, status: str | None = None):
        return self.storage.list_jobs(node_name, status=status)

    def cancel_job(self, node_name: str, job_id: int):
        self.storage.set_job_status(node_name, job_id, CANCELLED)
        self.refresh_node_status(node_name, allow_complete=False)

    def retry_job(self, node_name: str, job_id: int):
        self.storage.set_job_status(node_name, job_id, QUEUED)
        self.storage.set_node_status(node_name, QUEUED)

    def skip_node(self, node_name: str):
        self.storage.set_node_status(node_name, SKIPPED)

    def mark_node_done(self, node_name: str):
        self.storage.set_node_status(node_name, DONE)

    def input_dir(self, node_name: str) -> Path:
        return self.storage.node_input_dir(node_name)

    def output_dir(self, node_name: str) -> Path:
        return self.storage.node_output_dir(node_name)