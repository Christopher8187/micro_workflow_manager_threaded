from pathlib import Path
from queue import Queue
from threading import Event, Thread
from time import perf_counter
from typing import Callable, TypeVar

from ..context import JobContext
from ..errors import (
    InvalidGraphError,
    InvalidJobError,
    JobFailedError,
    JobRestartedError,
    JobTimeoutError,
)
from ..models import CANCELLED, DONE, FAILED, QUEUED, RUNNING, SKIPPED, Job, now
from ..fibers import cancellation_scope, in_fiber_runtime
from ..networking import network_attempt_context


T = TypeVar("T")


class JobExecutionMixin:
    restart_poll_interval_seconds = 0.05

    def run_job_side_effect(
        self,
        node_name: str,
        job_id: int,
        generation: int,
        execution_id: str | None,
        action: Callable[[], T],
    ) -> T:
        """Run a JobContext mutation only while its execution lease is current."""
        if execution_id is None:
            return action()
        return self.storage.run_guarded_job_side_effect(
            node_name,
            job_id,
            generation,
            execution_id,
            action,
        )

    def check_job_execution(
        self,
        node_name: str,
        job_id: int,
        generation: int,
        execution_id: str | None,
    ):
        """Cheap cooperative cancellation check without a mutation lock."""
        if execution_id is None:
            return
        if not self.storage.job_execution_is_current(
            node_name,
            job_id,
            generation,
            execution_id,
        ):
            raise JobRestartedError(
                f"Job {node_name}/{job_id} generation {generation} was restarted"
            )

    def _run_job_unfenced(
        self,
        node_name: str,
        job_id: int,
    ):
        """Run a job through the original low-overhead execution path.

        This path is used for normal programmatic MicroWorkflow calls. The CLI
        enables the generation-fenced supervisor only while it owns an active
        run/runfrom sequence.
        """
        job = self.storage.load_job(node_name, job_id)
        started_at = now()
        started_perf = perf_counter()
        self.storage.set_job_status(node_name, job_id, RUNNING, started_at=started_at)

        try:
            previous_node_name = getattr(self._job_context, "node_name", None)
            previous_job_id = getattr(self._job_context, "job_id", None)
            previous_generation = getattr(self._job_context, "generation", None)
            previous_execution_id = getattr(self._job_context, "execution_id", None)
            self._job_context.node_name = node_name
            self._job_context.job_id = job_id
            self._job_context.generation = 0
            self._job_context.execution_id = None
            try:
                result = self.execute_with_fallbacks(
                    job,
                    execution_generation=0,
                    execution_id=None,
                )
            finally:
                self._job_context.node_name = previous_node_name
                self._job_context.job_id = previous_job_id
                self._job_context.generation = previous_generation
                self._job_context.execution_id = previous_execution_id

            stored_files = self.storage.store_returned_files(node_name, job_id, result)
            self.storage.write_output(
                node_name,
                job_id,
                {
                    "status": DONE,
                    "stored_files": stored_files,
                    "result_type": type(result).__name__,
                    "result_repr": repr(result),
                },
            )
            self.storage.set_job_status(
                node_name,
                job_id,
                DONE,
                started_at=started_at,
                finished_at=now(),
                duration_seconds=round(perf_counter() - started_perf, 6),
            )

            if self.storage.get_node_status(node_name) != RUNNING:
                self.refresh_node_status(node_name, allow_complete=False)
            return result

        except Exception as error:
            self.storage.write_debug(node_name, f"job {job_id} failed: {error}")
            self.storage.write_output(
                node_name,
                job_id,
                {"status": FAILED, "error": repr(error)},
            )
            self.storage.set_job_status(
                node_name,
                job_id,
                FAILED,
                started_at=started_at,
                finished_at=now(),
                duration_seconds=round(perf_counter() - started_perf, 6),
            )

            if self.storage.get_node_status(node_name) != RUNNING:
                self.refresh_node_status(node_name, allow_complete=False)
            raise JobFailedError(f"Job {node_name}/{job_id} failed") from error

    def run_job(
        self,
        node_name: str,
        job_id: int,
        ignore_readiness: bool = False,
    ):
        if not ignore_readiness and not self.node_ready(node_name):
            raise InvalidGraphError(f"Node {node_name} is not ready yet")

        node = self.nodes[node_name]
        if node.main_task is None:
            raise InvalidJobError(f"Node {node_name} has no mounted task")

        if not self.active_job_restart_enabled:
            return self._run_job_unfenced(node_name, job_id)

        # The runner worker is now the attempt controller. It invokes the
        # fallback/retry pipeline synchronously and creates only one extra
        # abandonable thread for the currently executing user handler. A
        # restart wakes this controller, which immediately loops into the new
        # generation while the stale handler remains fenced.
        while True:
            job = self.storage.load_job(node_name, job_id)
            started_at = now()
            started_perf = perf_counter()
            generation, execution_id = self.storage.claim_job_execution(
                node_name, job_id, started_at=started_at
            )

            try:
                result = self.execute_with_fallbacks(
                    job,
                    execution_generation=generation,
                    execution_id=execution_id,
                )
                outcome_kind, payload = "result", result
            except JobRestartedError as error:
                self.scheduler_supervisor.cancel_execution(
                    node_name,
                    job_id,
                    generation,
                    execution_id,
                    reason=str(error),
                )
                self.storage.write_debug(
                    node_name,
                    f"job {job_id} generation {generation} superseded; "
                    "starting the requested replacement",
                )
                continue
            except BaseException as error:
                outcome_kind, payload = "error", error

            try:
                with self.storage.guard_job_execution(
                    node_name, job_id, generation, execution_id
                ):
                    if outcome_kind == "result":
                        result = payload
                        stored_files = self.storage.store_returned_files(
                            node_name, job_id, result
                        )
                        self.storage.write_output(
                            node_name,
                            job_id,
                            {
                                "status": DONE,
                                "stored_files": stored_files,
                                "result_type": type(result).__name__,
                                "result_repr": repr(result),
                                "generation": generation,
                            },
                        )
                        self.storage.set_job_status(
                            node_name,
                            job_id,
                            DONE,
                            started_at=started_at,
                            finished_at=now(),
                            duration_seconds=round(perf_counter() - started_perf, 6),
                            generation=generation,
                            execution_id=execution_id,
                        )
                    else:
                        error = payload
                        self.storage.write_debug(node_name, f"job {job_id} failed: {error}")
                        self.storage.write_output(
                            node_name,
                            job_id,
                            {
                                "status": FAILED,
                                "error": repr(error),
                                "generation": generation,
                            },
                        )
                        self.storage.set_job_status(
                            node_name,
                            job_id,
                            FAILED,
                            started_at=started_at,
                            finished_at=now(),
                            duration_seconds=round(perf_counter() - started_perf, 6),
                            generation=generation,
                            execution_id=execution_id,
                        )
            except JobRestartedError:
                self.storage.write_debug(
                    node_name,
                    f"job {job_id} generation {generation} finished while a "
                    "restart was being prepared; stale completion discarded",
                )
                continue

            if self.storage.get_node_status(node_name) != RUNNING:
                self.refresh_node_status(node_name, allow_complete=False)

            if outcome_kind == "result":
                return payload
            error = payload
            if isinstance(error, BaseException) and not isinstance(error, Exception):
                raise error
            raise JobFailedError(f"Job {node_name}/{job_id} failed") from error

    def _call_mounted_handler(self, mounted, ctx: JobContext, params: dict):
        previous_node_name = getattr(self._job_context, "node_name", None)
        previous_job_id = getattr(self._job_context, "job_id", None)
        previous_generation = getattr(self._job_context, "generation", None)
        previous_execution_id = getattr(self._job_context, "execution_id", None)
        self._job_context.node_name = ctx.current_node
        self._job_context.job_id = ctx.job_id
        self._job_context.generation = ctx.execution_generation
        self._job_context.execution_id = ctx.execution_id
        try:
            return mounted.handler(ctx, **params)
        finally:
            self._job_context.node_name = previous_node_name
            self._job_context.job_id = previous_job_id
            self._job_context.generation = previous_generation
            self._job_context.execution_id = previous_execution_id

    def _invoke_handler_with_timeout(
        self,
        mounted,
        ctx: JobContext,
        params: dict,
        watch,
    ):
        """Invoke one handler with at most one abandonable handler thread.

        The current runner worker is the controller. Untimed programmatic jobs
        execute directly. Timeout-supervised or actively restartable CLI jobs
        run the user handler in exactly one daemon thread; the controller waits
        for completion, a centralized deadline, or a changed execution lease.
        """
        supervisor = self.scheduler_supervisor

        if in_fiber_runtime():
            def check_cancelled() -> None:
                ctx.raise_if_cancelled()
            try:
                with cancellation_scope(check_cancelled), network_attempt_context(self, ctx, watch):
                    result = self._call_mounted_handler(mounted, ctx, params)
                check_cancelled()
            except BaseException as error:
                restart_error = supervisor.execution_cancel_error(watch)
                timeout_error = supervisor.timeout_error(watch)
                final_error = restart_error or timeout_error or error
                state = (
                    "superseded" if restart_error is not None
                    else "timed_out" if timeout_error is not None
                    else "failed"
                )
                supervisor.finish_attempt(watch, state=state, error=final_error)
                raise final_error
            else:
                supervisor.signal_handler_complete(watch)
                supervisor.finish_attempt(watch, state="completed")
                return result

        if not watch.abandonable:
            try:
                result = self._call_mounted_handler(mounted, ctx, params)
            except BaseException as error:
                supervisor.finish_attempt(watch, state="failed", error=error)
                raise
            else:
                supervisor.finish_attempt(watch, state="completed")
                return result

        outcomes: Queue = Queue(maxsize=1)

        def target():
            try:
                outcomes.put(("result", self._call_mounted_handler(mounted, ctx, params)))
            except BaseException as error:
                outcomes.put(("error", error))
            finally:
                supervisor.signal_handler_complete(watch)
                self.storage.close_thread_connection()

        Thread(
            target=target,
            name=f"mwf-handler-{ctx.current_node}-{ctx.job_id}-{mounted.name}",
            daemon=True,
        ).start()

        while not watch.wake_event.wait(self.restart_poll_interval_seconds):
            if ctx.execution_id is not None and not self.storage.job_execution_is_current(
                ctx.current_node,
                ctx.job_id,
                ctx.execution_generation,
                ctx.execution_id,
            ):
                supervisor.cancel_execution(
                    ctx.current_node,
                    ctx.job_id,
                    ctx.execution_generation,
                    ctx.execution_id,
                    reason=(
                        f"Job {ctx.current_node}/{ctx.job_id} generation "
                        f"{ctx.execution_generation} was restarted"
                    ),
                )

        restart_error = supervisor.execution_cancel_error(watch)
        if restart_error is not None:
            supervisor.finish_attempt(watch, state="superseded", error=restart_error)
            raise restart_error

        timeout_error = supervisor.timeout_error(watch)
        if timeout_error is not None:
            supervisor.finish_attempt(watch, state="timed_out", error=timeout_error)
            raise timeout_error

        kind, payload = outcomes.get()
        if kind == "error":
            supervisor.finish_attempt(watch, state="failed", error=payload)
            raise payload

        supervisor.finish_attempt(watch, state="completed")
        return payload

    def execute_with_fallbacks(
        self,
        job: Job,
        *,
        execution_generation: int,
        execution_id: str | None,
    ):
        node = self.nodes[job.node_name]
        assert node.main_task is not None

        try:
            return self.execute_mounted_task(
                job,
                node.main_task,
                execution_generation=execution_generation,
                execution_id=execution_id,
            )

        except JobRestartedError:
            raise
        except Exception as main_error:
            terminal_error = main_error
            self.check_job_execution(
                job.node_name,
                job.job_id,
                execution_generation,
                execution_id,
            )
            self.storage.write_debug(
                job.node_name,
                f"job {job.job_id} main task failed: {main_error}",
            )

            for fallback_name in node.fallback_order:
                fallback = node.fallbacks[fallback_name]

                self.storage.write_debug(
                    job.node_name,
                    f"job {job.job_id} trying fallback {fallback_name}",
                )
                self.storage.append_job_event(
                    job.node_name,
                    job.job_id,
                    "fallback_started",
                    fallback=fallback_name,
                    previous_error=repr(main_error),
                )

                try:
                    return self.execute_mounted_task(
                        job,
                        fallback,
                        previous_error=main_error,
                        execution_generation=execution_generation,
                        execution_id=execution_id,
                    )

                except JobRestartedError:
                    raise
                except Exception as fallback_error:
                    terminal_error = fallback_error
                    self.check_job_execution(
                        job.node_name,
                        job.job_id,
                        execution_generation,
                        execution_id,
                    )
                    self.storage.write_debug(
                        job.node_name,
                        f"job {job.job_id} fallback {fallback_name} failed: {fallback_error}",
                    )

            if terminal_error is main_error:
                raise main_error
            raise terminal_error from main_error

    def execute_mounted_task(
        self,
        job: Job,
        mounted,
        previous_error: Exception | None = None,
        *,
        execution_generation: int,
        execution_id: str | None,
    ):
        attempts = mounted.retries + 1
        all_results = []

        for attempt in range(1, attempts + 1):
            try:
                repeat_results = []

                for repeat_index in range(1, mounted.repeats + 1):
                    # Validate invocation inputs before registering a scheduler
                    # watch. A malformed job must not leave an orphan deadline
                    # that can fire after the validation error is already being
                    # handled by retry/fallback logic.
                    params = {
                        key: value
                        for key, value in job.params.items()
                        if key in mounted.allowed_params
                    }

                    if "error" in mounted.allowed_params:
                        params["error"] = previous_error

                    missing = mounted.required_params - set(params)
                    if missing:
                        raise InvalidJobError(
                            f"Missing params for {job.node_name}.{mounted.name}: {missing}"
                        )

                    cancellation_event = Event()
                    watch = self.scheduler_supervisor.create_attempt(
                        node_name=job.node_name,
                        job_id=job.job_id,
                        task_name=mounted.name,
                        attempt=attempt,
                        repeat_index=repeat_index,
                        generation=execution_generation,
                        execution_id=execution_id,
                        cancellation_event=cancellation_event,
                        total_timeout=mounted.timeout,
                        checkpoint_timeout=mounted.checkpoint_timeout,
                        force_abandonable=(
                            self.active_job_restart_enabled and execution_id is not None
                        ),
                    )
                    ctx = JobContext(
                        system=self,
                        current_node=job.node_name,
                        current_job=job,
                        current_task=mounted.name,
                        attempt=attempt,
                        repeat_index=repeat_index,
                        error=previous_error,
                        execution_generation=execution_generation,
                        execution_id=execution_id,
                        cancellation_event=cancellation_event,
                        attempt_watch=watch,
                    )

                    result = self._invoke_handler_with_timeout(
                        mounted,
                        ctx,
                        params,
                        watch,
                    )
                    ctx.raise_if_cancelled()
                    repeat_results.append(result)

                all_results.extend(repeat_results)
                return all_results[0] if len(all_results) == 1 else all_results

            except JobRestartedError:
                raise
            except Exception as error:
                if attempt < attempts:
                    self.check_job_execution(
                        job.node_name,
                        job.job_id,
                        execution_generation,
                        execution_id,
                    )
                    self.storage.write_debug(
                        job.node_name,
                        f"job {job.job_id} retrying {mounted.name} "
                        f"attempt {attempt + 1}/{attempts}: {error}",
                    )
                    self.storage.append_job_event(
                        job.node_name,
                        job.job_id,
                        "retry_started",
                        task=mounted.name,
                        attempt=attempt + 1,
                        attempts=attempts,
                        previous_error=repr(error),
                    )
                    continue

                raise

    def run_one(self, node_name: str, **params):
        job = self.start(
            node_name,
            autostart=False,
            **params,
        )

        result = self.run_job(
            node_name=node_name,
            job_id=job.job_id,
            ignore_readiness=True,
        )
        self.refresh_node_status(node_name, allow_complete=True)
        return result

    def run_node_once(self, node_name: str):
        return self.run_node(
            node_name,
            ignore_readiness=True,
        )

    def list_jobs(self, node_name: str, status: str | None = None):
        return self.storage.list_jobs(node_name, status=status)

    def cancel_job(self, node_name: str, job_id: int):
        self.storage.set_job_status(node_name, job_id, CANCELLED)
        self.refresh_node_status(node_name, allow_complete=False)

    def retry_job(self, node_name: str, job_id: int):
        self.storage.request_job_restart(
            node_name,
            job_id,
            reason="retry_job API",
        )
        self.storage.set_node_status(node_name, QUEUED)

    def skip_node(self, node_name: str):
        self.storage.set_node_status(node_name, SKIPPED)

    def mark_node_done(self, node_name: str):
        self.storage.set_node_status(node_name, DONE)

    def input_dir(self, node_name: str) -> Path:
        return self.storage.node_input_dir(node_name)

    def output_dir(self, node_name: str) -> Path:
        return self.storage.node_output_dir(node_name)
